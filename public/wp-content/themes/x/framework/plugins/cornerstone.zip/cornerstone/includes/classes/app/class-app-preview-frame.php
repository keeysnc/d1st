<?php

class Cornerstone_App_Preview_Frame extends Cornerstone_Plugin_Component {

  public function setup() {

  }

}
